# DAFTAR LENGKAP FILE APLIKASI

## Struktur Folder Utama

```
sistem-kegiatan-absensi/
├── config/                    # Konfigurasi aplikasi
├── controllers/               # Business logic
├── models/                    # Database logic  
├── views/                     # User interface
├── assets/                    # CSS, JS, Images
├── database.sql              # File SQL database
├── index.php                 # Entry point
├── .htaccess                 # Apache configuration
├── README.md                 # Dokumentasi utama
├── PANDUAN_INSTALASI.md      # Panduan instalasi detail
└── TESTING_CHECKLIST.md      # Checklist testing
```

## File Config (2 files)
- config/config.php - Konfigurasi database dan aplikasi
- config/database.php - Class koneksi database

## File Controllers (6 files)
- controllers/AuthController.php - Login, logout, session
- controllers/UserController.php - CRUD user (Admin)
- controllers/KegiatanController.php - CRUD kegiatan (Admin)
- controllers/AbsensiController.php - CRUD absensi
- controllers/ProfileController.php - Ubah password
- controllers/auth_handler.php - Handler login/logout

## File Models (3 files)
- models/UserModel.php - Query database users
- models/KegiatanModel.php - Query database kegiatan
- models/AbsensiModel.php - Query database absensi

## File Views - Admin (13 files)
### Dashboard
- views/admin/dashboard.php

### Users (CRUD)
- views/admin/users/index.php - Daftar user
- views/admin/users/create.php - Form tambah user
- views/admin/users/edit.php - Form edit user
- views/admin/users/delete.php - Handler hapus user

### Kegiatan (CRUD)
- views/admin/kegiatan/index.php - Daftar kegiatan
- views/admin/kegiatan/create.php - Form tambah kegiatan
- views/admin/kegiatan/edit.php - Form edit kegiatan
- views/admin/kegiatan/delete.php - Handler hapus kegiatan

### Absensi (Read only untuk admin)
- views/admin/absensi/index.php - Daftar semua absensi
- views/admin/absensi/edit.php - Form edit absensi

### Profile
- views/admin/profile/index.php - Profil & ubah password

## File Views - User (7 files)
### Dashboard
- views/user/dashboard.php

### Kegiatan (Read only)
- views/user/kegiatan/index.php - Lihat daftar kegiatan

### Absensi (CRU - Create Read Update)
- views/user/absensi/index.php - Daftar absensi milik sendiri
- views/user/absensi/create.php - Form tambah absensi
- views/user/absensi/edit.php - Form edit absensi sendiri

### Profile
- views/user/profile/index.php - Profil & ubah password

## File Views - Shared (3 files)
- views/auth/login.php - Halaman login
- views/components/admin_navbar.php - Navbar untuk admin
- views/components/user_navbar.php - Navbar untuk user

## File Database
- database.sql - Schema database lengkap dengan data dummy

## File Entry Point
- index.php - Halaman utama (redirect ke login)

## File Configuration
- .htaccess - Konfigurasi Apache (security)

## File Dokumentasi
- README.md - Dokumentasi utama aplikasi
- PANDUAN_INSTALASI.md - Panduan instalasi step-by-step
- TESTING_CHECKLIST.md - Checklist untuk testing

---

## TOTAL FILES

### Core Application Files:
- Config: 2 files
- Controllers: 6 files
- Models: 3 files
- Views Admin: 13 files
- Views User: 7 files
- Views Shared: 3 files
- Database: 1 file
- Entry: 1 file
- Config: 1 file

**TOTAL: 37+ file PHP**

### Documentation Files:
- README.md
- PANDUAN_INSTALASI.md
- TESTING_CHECKLIST.md

---

## KETERANGAN ROLE & HAK AKSES

### ADMIN bisa:
✅ Login & Logout
✅ CRUD User (Create, Read, Update, Delete)
✅ CRUD Kegiatan (Create, Read, Update, Delete)
✅ Read semua Absensi (hanya lihat)
✅ Update Absensi (edit data absensi user)
✅ Ubah password sendiri

### USER bisa:
✅ Login & Logout
✅ Read Kegiatan (hanya lihat)
✅ Create Absensi (tambah)
✅ Read Absensi milik sendiri (lihat)
✅ Update Absensi milik sendiri (edit)
✅ Ubah password sendiri

### USER TIDAK bisa:
❌ Delete apapun
❌ CRUD User
❌ CRUD Kegiatan
❌ Lihat/edit absensi user lain

---

© 2026 Sistem Manajemen Kegiatan & Absensi
