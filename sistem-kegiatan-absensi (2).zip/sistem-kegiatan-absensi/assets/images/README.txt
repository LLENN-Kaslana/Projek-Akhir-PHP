Folder untuk menyimpan gambar
