<?php
// Test file untuk cek login
require_once 'config/config.php';
require_once 'config/database.php';
require_once 'models/UserModel.php';

$userModel = new UserModel();

echo "=== TEST LOGIN ===\n\n";

// Test login admin
echo "Test 1: Login Admin\n";
$user = $userModel->login('admin', 'admin123');
if ($user) {
    echo "✅ Login berhasil: " . $user['nama_lengkap'] . " (" . $user['role'] . ")\n";
} else {
    echo "❌ Login gagal\n";
}

echo "\n";

// Test login user
echo "Test 2: Login User\n";
$user = $userModel->login('user1', 'user123');
if ($user) {
    echo "✅ Login berhasil: " . $user['nama_lengkap'] . " (" . $user['role'] . ")\n";
} else {
    echo "❌ Login gagal\n";
}

echo "\n";

// Test password verify
echo "Test 3: Verify Password Hash\n";
$testPass = 'admin123';
$hash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';
if (password_verify($testPass, $hash)) {
    echo "✅ Password hash valid\n";
} else {
    echo "❌ Password hash tidak valid\n";
}
