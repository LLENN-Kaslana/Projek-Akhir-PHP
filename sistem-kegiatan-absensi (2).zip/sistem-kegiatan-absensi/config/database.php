<?php
/**
 * Class Database
 * Mengelola koneksi ke database MySQL
 */

class Database {
    private $host = DB_HOST;
    private $user = DB_USER;
    private $pass = DB_PASS;
    private $dbname = DB_NAME;
    
    private $conn;
    private $error;
    
    /**
     * Konstruktor - Membuat koneksi database
     */
    public function __construct() {
        $this->connect();
    }
    
    /**
     * Melakukan koneksi ke database
     */
    private function connect() {
        $this->conn = null;
        
        try {
            $this->conn = new mysqli($this->host, $this->user, $this->pass, $this->dbname);
            
            if ($this->conn->connect_error) {
                throw new Exception("Koneksi gagal: " . $this->conn->connect_error);
            }
            
            // Set charset ke utf8mb4
            $this->conn->set_charset("utf8mb4");
            
        } catch (Exception $e) {
            $this->error = $e->getMessage();
            die("Error Database: " . $this->error);
        }
    }
    
    /**
     * Mendapatkan koneksi database
     */
    public function getConnection() {
        return $this->conn;
    }
    
    /**
     * Menutup koneksi database
     */
    public function closeConnection() {
        if ($this->conn) {
            $this->conn->close();
        }
    }
    
    /**
     * Escape string untuk mencegah SQL Injection
     */
    public function escapeString($string) {
        return $this->conn->real_escape_string($string);
    }
    
    /**
     * Mengecek apakah tabel ada
     */
    public function tableExists($tableName) {
        $result = $this->conn->query("SHOW TABLES LIKE '$tableName'");
        return $result && $result->num_rows > 0;
    }
}
?>
