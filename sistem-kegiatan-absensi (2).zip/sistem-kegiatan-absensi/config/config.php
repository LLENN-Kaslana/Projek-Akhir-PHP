<?php
/**
 * File Konfigurasi Database
 * Berisi pengaturan koneksi ke database MySQL
 */

// Konfigurasi Database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'db_kegiatan_absensi');

// Konfigurasi Aplikasi
define('BASE_URL', 'http://localhost/sistem-kegiatan-absensi/');
define('APP_NAME', 'Sistem Manajemen Kegiatan & Absensi');

// Timezone
date_default_timezone_set('Asia/Jakarta');

// Session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
