<?php
/**
 * FILE TEST KONEKSI - Untuk debugging
 * Letakkan di root folder: sistem-kegiatan-absensi/test_koneksi.php
 * Akses: http://localhost/sistem-kegiatan-absensi/test_koneksi.php
 */

echo "<h1>TEST KONEKSI & KONFIGURASI</h1>";
echo "<hr>";

// Test 1: PHP Version
echo "<h2>1. PHP Version</h2>";
echo "PHP Version: " . phpversion() . "<br>";
echo "✅ PHP OK<br><br>";

// Test 2: File Structure
echo "<h2>2. File Structure</h2>";
$files_required = [
    'index.php',
    'config/config.php',
    'config/database.php',
    'controllers/auth_handler.php',
    'views/auth/login.php',
    'database.sql'
];

foreach ($files_required as $file) {
    if (file_exists($file)) {
        echo "✅ $file EXISTS<br>";
    } else {
        echo "❌ $file MISSING<br>";
    }
}
echo "<br>";

// Test 3: Config File
echo "<h2>3. Config Values</h2>";
if (file_exists('config/config.php')) {
    require_once 'config/config.php';
    echo "DB_HOST: " . DB_HOST . "<br>";
    echo "DB_USER: " . DB_USER . "<br>";
    echo "DB_NAME: " . DB_NAME . "<br>";
    echo "BASE_URL: " . BASE_URL . "<br>";
    echo "<br>";
    
    // Test 4: Database Connection
    echo "<h2>4. Database Connection</h2>";
    try {
        require_once 'config/database.php';
        $db = new Database();
        echo "✅ Database connection SUCCESS<br><br>";
        
        // Test 5: Check Tables
        echo "<h2>5. Database Tables</h2>";
        $conn = $db->getConnection();
        $result = $conn->query("SHOW TABLES");
        
        if ($result && $result->num_rows > 0) {
            echo "Tables found:<br>";
            while ($row = $result->fetch_array()) {
                echo "✅ " . $row[0] . "<br>";
            }
        } else {
            echo "❌ No tables found! Please import database.sql<br>";
        }
        echo "<br>";
        
        // Test 6: Check Users
        echo "<h2>6. Check Users Table</h2>";
        $result = $conn->query("SELECT COUNT(*) as total FROM users");
        if ($result) {
            $row = $result->fetch_assoc();
            echo "Total users: " . $row['total'] . "<br>";
            
            if ($row['total'] > 0) {
                echo "✅ Users table OK<br>";
                
                // Show users
                $result = $conn->query("SELECT id, username, nama_lengkap, role FROM users");
                echo "<br>Users list:<br>";
                echo "<table border='1' cellpadding='5'>";
                echo "<tr><th>ID</th><th>Username</th><th>Nama</th><th>Role</th></tr>";
                while ($user = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $user['id'] . "</td>";
                    echo "<td>" . $user['username'] . "</td>";
                    echo "<td>" . $user['nama_lengkap'] . "</td>";
                    echo "<td>" . $user['role'] . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "❌ Users table EMPTY! Please import database.sql<br>";
            }
        }
        
    } catch (Exception $e) {
        echo "❌ Database ERROR: " . $e->getMessage() . "<br>";
    }
} else {
    echo "❌ config/config.php NOT FOUND<br>";
}

echo "<br><hr>";
echo "<h2>KESIMPULAN</h2>";
echo "<p>Jika semua centang hijau (✅), aplikasi siap digunakan.</p>";
echo "<p>Jika ada tanda silang merah (❌), perbaiki masalah tersebut terlebih dahulu.</p>";
echo "<br>";
echo "<h3>LANGKAH SELANJUTNYA:</h3>";
echo "<ol>";
echo "<li>Jika semua OK, akses: <a href='index.php'>index.php (Halaman Login)</a></li>";
echo "<li>Login dengan:<br>- Username: <strong>admin</strong><br>- Password: <strong>admin123</strong></li>";
echo "</ol>";
?>
