-- ========================================
-- DATABASE SISTEM MANAJEMEN KEGIATAN & ABSENSI
-- ========================================

-- Buat database baru
CREATE DATABASE IF NOT EXISTS db_kegiatan_absensi;
USE db_kegiatan_absensi;

-- ========================================
-- TABEL USERS
-- ========================================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    nama_lengkap VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    role ENUM('Admin', 'User 1', 'User 2', 'User 3', 'User 4') NOT NULL,
    foto_profil VARCHAR(255) DEFAULT 'default.png',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========================================
-- TABEL KEGIATAN
-- ========================================
CREATE TABLE IF NOT EXISTS kegiatan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_kegiatan VARCHAR(200) NOT NULL,
    deskripsi TEXT,
    tanggal_mulai DATE NOT NULL,
    tanggal_selesai DATE NOT NULL,
    lokasi VARCHAR(200),
    pic_id INT NOT NULL,
    status ENUM('Belum Mulai', 'Sedang Berjalan', 'Selesai') DEFAULT 'Belum Mulai',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (pic_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========================================
-- TABEL ABSENSI
-- ========================================
CREATE TABLE IF NOT EXISTS absensi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kegiatan_id INT NOT NULL,
    user_id INT NOT NULL,
    tanggal_absen DATE NOT NULL,
    waktu_absen TIME NOT NULL,
    status_kehadiran ENUM('Hadir', 'Izin', 'Sakit', 'Alfa') NOT NULL,
    keterangan TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (kegiatan_id) REFERENCES kegiatan(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_absensi (kegiatan_id, user_id, tanggal_absen)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ========================================
-- DATA AWAL (DUMMY DATA)
-- ========================================

-- Insert Admin (password: admin123)
INSERT INTO users (username, password, nama_lengkap, email, role) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator', 'admin@system.com', 'Admin');

-- Insert Users (password: user123)
INSERT INTO users (username, password, nama_lengkap, email, role) VALUES
('user1', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', 'Budi Santoso', 'budi@email.com', 'User 1'),
('user2', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', 'Siti Nurhaliza', 'siti@email.com', 'User 2'),
('user3', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', 'Andi Wijaya', 'andi@email.com', 'User 3'),
('user4', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', 'Dewi Lestari', 'dewi@email.com', 'User 4');

-- Insert Kegiatan
INSERT INTO kegiatan (nama_kegiatan, deskripsi, tanggal_mulai, tanggal_selesai, lokasi, pic_id, status) VALUES
('Workshop Web Development', 'Pelatihan pembuatan website menggunakan PHP dan MySQL', '2026-02-10', '2026-02-12', 'Ruang Seminar A', 1, 'Belum Mulai'),
('Seminar Teknologi AI', 'Seminar tentang perkembangan teknologi Artificial Intelligence', '2026-02-15', '2026-02-15', 'Auditorium Utama', 1, 'Belum Mulai'),
('Rapat Koordinasi Tim', 'Rapat koordinasi bulanan tim pengembangan', '2026-02-08', '2026-02-08', 'Ruang Rapat B', 2, 'Selesai');

-- Insert Absensi
INSERT INTO absensi (kegiatan_id, user_id, tanggal_absen, waktu_absen, status_kehadiran, keterangan) VALUES
(3, 2, '2026-02-08', '09:00:00', 'Hadir', 'Tepat waktu'),
(3, 3, '2026-02-08', '09:15:00', 'Hadir', 'Sedikit terlambat'),
(3, 4, '2026-02-08', '09:00:00', 'Hadir', 'Tepat waktu'),
(3, 5, '2026-02-08', '09:00:00', 'Izin', 'Ada keperluan keluarga');

-- ========================================
-- INFO LOGIN
-- ========================================
-- Admin:
--   Username: admin
--   Password: admin123
-- 
-- User 1-4:
--   Username: user1, user2, user3, user4
--   Password: user123
-- ========================================
