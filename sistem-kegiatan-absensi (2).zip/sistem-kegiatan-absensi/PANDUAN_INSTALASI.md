# PANDUAN INSTALASI
## Sistem Informasi Manajemen Kegiatan dan Absensi

---

## A. PERSIAPAN

### 1. Software Yang Dibutuhkan:
- **XAMPP** (untuk Windows/Mac) atau **LAMP** (untuk Linux)
  Download dari: https://www.apachefriends.org/
- **Web Browser** (Chrome, Firefox, Edge)
- **Text Editor** (Visual Studio Code - sudah digunakan)

### 2. Spesifikasi Minimum:
- PHP versi 7.4 atau lebih tinggi
- MySQL versi 5.7 atau lebih tinggi
- Apache Web Server
- RAM minimal 2GB

---

## B. LANGKAH INSTALASI

### LANGKAH 1: Install XAMPP

1. Download XAMPP dari website resmi
2. Install XAMPP di komputer Anda
3. Lokasi default instalasi:
   - Windows: `C:\xampp\`
   - Mac: `/Applications/XAMPP/`
   - Linux: `/opt/lampp/`

### LANGKAH 2: Copy Aplikasi

1. Copy folder `sistem-kegiatan-absensi` ke dalam folder `htdocs`
2. Lokasi folder htdocs:
   - Windows: `C:\xampp\htdocs\`
   - Mac: `/Applications/XAMPP/htdocs/`
   - Linux: `/opt/lampp/htdocs/`

3. Setelah dicopy, struktur folder menjadi:
   ```
   htdocs/
   └── sistem-kegiatan-absensi/
       ├── config/
       ├── controllers/
       ├── models/
       ├── views/
       ├── assets/
       ├── database.sql
       └── index.php
   ```

### LANGKAH 3: Jalankan XAMPP

1. Buka XAMPP Control Panel
2. Start service **Apache** (klik tombol Start)
3. Start service **MySQL** (klik tombol Start)
4. Pastikan kedua service berwarna hijau (running)

### LANGKAH 4: Buat Database

#### Cara 1: Manual via phpMyAdmin
1. Buka browser, akses: `http://localhost/phpmyadmin`
2. Klik tab "Database" atau "New" (tergantung versi)
3. Buat database baru dengan nama: `db_kegiatan_absensi`
4. Klik tab "Import"
5. Klik "Choose File" dan pilih file `database.sql`
6. Scroll kebawah dan klik tombol "Go" atau "Import"
7. Tunggu hingga muncul pesan "Import has been successfully finished"

#### Cara 2: Via SQL Query
1. Buka browser, akses: `http://localhost/phpmyadmin`
2. Klik tab "SQL"
3. Copy seluruh isi file `database.sql`
4. Paste ke kotak query
5. Klik tombol "Go"

### LANGKAH 5: Konfigurasi Aplikasi

1. Buka file `config/config.php` menggunakan Visual Studio Code
2. Periksa dan sesuaikan konfigurasi database:

```php
// Jika password MySQL Anda kosong (default XAMPP)
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');  // kosong
define('DB_NAME', 'db_kegiatan_absensi');

// Jika password MySQL Anda ada (contoh: 'password123')
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'password123');  // sesuaikan
define('DB_NAME', 'db_kegiatan_absensi');
```

3. Pastikan BASE_URL sudah benar:
```php
define('BASE_URL', 'http://localhost/sistem-kegiatan-absensi/');
```

4. Save file (Ctrl+S)

### LANGKAH 6: Jalankan Aplikasi

1. Buka browser
2. Akses URL: `http://localhost/sistem-kegiatan-absensi/`
3. Anda akan melihat halaman login

---

## C. LOGIN PERTAMA KALI

### Akun Admin:
- **Username:** admin
- **Password:** admin123

### Akun User (untuk testing):
- **Username:** user1, user2, user3, atau user4
- **Password:** user123

### Tips Keamanan:
⚠️ **PENTING:** Setelah login pertama kali, segera ubah password default melalui menu Profil!

---

## D. PENGGUNAAN APLIKASI

### Untuk Admin:

1. **Login** menggunakan akun admin
2. **Dashboard Admin** akan menampilkan:
   - Total User
   - Total Kegiatan
   - Total Absensi
   - Kegiatan yang sedang berjalan
   - Absensi terbaru

3. **Menu Navigasi:**
   - **Dashboard:** Halaman utama
   - **User:** Kelola data pengguna (CRUD)
   - **Kegiatan:** Kelola data kegiatan (CRUD)
   - **Absensi:** Lihat semua data absensi
   - **Profil:** Ubah password
   - **Logout:** Keluar dari sistem

### Untuk User:

1. **Login** menggunakan akun user
2. **Dashboard User** akan menampilkan:
   - Total absensi yang sudah dibuat
   - Kegiatan yang sedang berjalan
   - Absensi terbaru milik user

3. **Menu Navigasi:**
   - **Dashboard:** Halaman utama
   - **Kegiatan:** Lihat daftar kegiatan (Read-only)
   - **Absensi:** Kelola absensi sendiri (Create, Read, Edit)
   - **Profil:** Ubah password
   - **Logout:** Keluar dari sistem

---

## E. TROUBLESHOOTING

### Masalah 1: "Database connection failed"

**Solusi:**
- Pastikan MySQL sudah running di XAMPP
- Cek username dan password di `config/config.php`
- Pastikan database `db_kegiatan_absensi` sudah dibuat
- Coba restart service MySQL di XAMPP

### Masalah 2: "Page not found" atau "404 Error"

**Solusi:**
- Pastikan Apache sudah running di XAMPP
- Cek BASE_URL di `config/config.php`
- Pastikan folder aplikasi ada di dalam `htdocs/`
- Coba akses: `http://localhost/sistem-kegiatan-absensi/index.php`

### Masalah 3: "Error session not working"

**Solusi:**
- Pastikan folder `C:\xampp\tmp` ada dan dapat ditulis (Windows)
- Atau pastikan `/tmp` dapat ditulis (Linux/Mac)
- Restart service Apache di XAMPP

### Masalah 4: Tampilan CSS tidak muncul

**Solusi:**
- Pastikan koneksi internet aktif (Tailwind CSS menggunakan CDN)
- Clear cache browser (Ctrl+Shift+Delete)
- Coba refresh halaman (Ctrl+F5)

### Masalah 5: Login gagal terus

**Solusi:**
- Pastikan database sudah di-import dengan benar
- Cek tabel `users` di phpMyAdmin, pastikan ada data
- Gunakan username dan password yang benar:
  - Admin: admin / admin123
  - User: user1 / user123

---

## F. FITUR-FITUR APLIKASI

### Admin dapat:
✅ Menambah, mengubah, menghapus user
✅ Menambah, mengubah, menghapus kegiatan
✅ Melihat semua data absensi
✅ Melihat laporan statistik
✅ Ubah password sendiri

### User dapat:
✅ Membuat absensi baru
✅ Melihat daftar kegiatan
✅ Melihat dan mengedit absensi milik sendiri
✅ Ubah password sendiri

### User TIDAK dapat:
❌ Menghapus data apapun
❌ Mengubah data user lain
❌ Mengedit data kegiatan
❌ Melihat absensi user lain

---

## G. TIPS PRESENTASI PROJECT

1. **Persiapan:**
   - Buka aplikasi 15 menit sebelum presentasi
   - Pastikan XAMPP sudah running
   - Test login dengan kedua role (Admin & User)

2. **Demo Urutan:**
   - Login sebagai Admin → Tunjukkan dashboard
   - Demo CRUD User (tambah, edit, hapus)
   - Demo CRUD Kegiatan
   - Lihat data absensi
   - Logout → Login sebagai User
   - Demo create absensi
   - Demo edit absensi sendiri
   - Tunjukkan tidak bisa hapus/edit data lain

3. **Highlight Teknis:**
   - Arsitektur MVC yang jelas
   - Role-based access control
   - Validasi form
   - Password hashing
   - Responsive design

---

## H. BACKUP & RESTORE

### Backup Database:
1. Buka phpMyAdmin
2. Pilih database `db_kegiatan_absensi`
3. Klik tab "Export"
4. Klik tombol "Go"
5. File .sql akan terdownload

### Restore Database:
1. Buka phpMyAdmin
2. Pilih database `db_kegiatan_absensi`
3. Klik tab "Import"
4. Choose File → pilih file backup .sql
5. Klik "Go"

---

## I. KONTAK & SUPPORT

Jika mengalami kesulitan:
1. Baca kembali dokumentasi ini dengan teliti
2. Cek troubleshooting section
3. Pastikan semua langkah sudah diikuti dengan benar

---

**SELAMAT MENGGUNAKAN SISTEM!**

© 2026 Sistem Manajemen Kegiatan & Absensi
Dibuat untuk Project Akhir
