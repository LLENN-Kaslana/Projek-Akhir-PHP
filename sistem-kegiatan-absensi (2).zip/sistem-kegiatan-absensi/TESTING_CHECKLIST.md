# CHECKLIST TESTING APLIKASI

## A. TESTING LOGIN

### Admin
- [ ] Login dengan username: admin, password: admin123
- [ ] Redirect ke dashboard admin setelah login berhasil
- [ ] Menampilkan pesan error jika username/password salah
- [ ] Logout berhasil dan kembali ke halaman login

### User
- [ ] Login dengan username: user1, password: user123
- [ ] Redirect ke dashboard user setelah login berhasil
- [ ] Menampilkan pesan error jika username/password salah
- [ ] Logout berhasil dan kembali ke halaman login

## B. TESTING ADMIN

### Dashboard
- [ ] Menampilkan total user
- [ ] Menampilkan total kegiatan
- [ ] Menampilkan total absensi
- [ ] Menampilkan kegiatan aktif
- [ ] Menampilkan absensi terbaru

### Kelola User
- [ ] Menampilkan daftar user
- [ ] Tambah user baru berhasil
- [ ] Edit user berhasil
- [ ] Hapus user berhasil (kecuali admin utama dan diri sendiri)
- [ ] Validasi form berfungsi
- [ ] Username tidak boleh duplikat

### Kelola Kegiatan
- [ ] Menampilkan daftar kegiatan
- [ ] Tambah kegiatan baru berhasil
- [ ] Edit kegiatan berhasil
- [ ] Hapus kegiatan berhasil
- [ ] Validasi tanggal berfungsi
- [ ] Dropdown PIC menampilkan semua user

### Lihat Absensi
- [ ] Menampilkan semua data absensi
- [ ] Data ditampilkan dengan benar (nama user, kegiatan, status)
- [ ] Filter/pencarian berfungsi (jika ada)

### Profil
- [ ] Menampilkan data profil admin
- [ ] Ubah password berhasil
- [ ] Validasi password lama benar
- [ ] Validasi password baru dan konfirmasi cocok

## C. TESTING USER

### Dashboard
- [ ] Menampilkan total absensi milik user
- [ ] Menampilkan kegiatan aktif
- [ ] Menampilkan absensi terbaru milik user

### Lihat Kegiatan
- [ ] Menampilkan daftar semua kegiatan
- [ ] Tidak ada tombol tambah/edit/hapus
- [ ] Informasi kegiatan lengkap ditampilkan

### Kelola Absensi
- [ ] Menampilkan daftar absensi milik user sendiri
- [ ] Tambah absensi baru berhasil
- [ ] Edit absensi milik sendiri berhasil
- [ ] Tidak bisa edit absensi user lain
- [ ] Tidak ada tombol hapus
- [ ] Validasi tidak boleh absen 2x untuk kegiatan yang sama di tanggal yang sama

### Profil
- [ ] Menampilkan data profil user
- [ ] Ubah password berhasil
- [ ] Validasi password lama benar
- [ ] Validasi password baru dan konfirmasi cocok

## D. TESTING KEAMANAN

### Role-Based Access
- [ ] Admin tidak bisa akses halaman user
- [ ] User tidak bisa akses halaman admin
- [ ] Akses tanpa login redirect ke halaman login
- [ ] Session berfungsi dengan baik

### Validasi Data
- [ ] Field required tidak boleh kosong
- [ ] Email harus format yang benar
- [ ] Password minimal 6 karakter
- [ ] Tanggal selesai tidak boleh lebih awal dari tanggal mulai
- [ ] SQL Injection dicegah
- [ ] XSS dicegah

## E. TESTING UI/UX

### Tampilan
- [ ] Tampilan responsive di desktop
- [ ] Tampilan responsive di tablet
- [ ] Tampilan responsive di mobile
- [ ] Warna dan font konsisten
- [ ] Icon ditampilkan dengan benar

### Navigasi
- [ ] Navbar berfungsi dengan baik
- [ ] Active menu ditandai dengan benar
- [ ] Tombol back/batal berfungsi
- [ ] Alert/notifikasi muncul dengan benar
- [ ] Auto-hide alert setelah 5 detik

## F. TESTING DATABASE

### Koneksi
- [ ] Koneksi database berhasil
- [ ] Query berjalan dengan lancar
- [ ] Error handling berfungsi

### Relasi Tabel
- [ ] Foreign key berfungsi
- [ ] Cascade delete berfungsi
- [ ] Data consistency terjaga

## G. TESTING PERFORMA

- [ ] Halaman load cepat (< 2 detik)
- [ ] Query database efisien
- [ ] Tidak ada memory leak
- [ ] Session tidak conflict

---

**Catatan:**
- Centang (✓) setiap item yang sudah ditest
- Catat bug/error yang ditemukan
- Perbaiki bug sebelum presentasi
