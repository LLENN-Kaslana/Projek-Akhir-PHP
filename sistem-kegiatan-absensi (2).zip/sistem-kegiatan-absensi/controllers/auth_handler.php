<?php
/**
 * Handler untuk AuthController
 * Menangani request login dan logout
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/UserModel.php';
require_once __DIR__ . '/AuthController.php';

$action = $_GET['action'] ?? '';
$authController = new AuthController();

switch ($action) {
    case 'login':
        $authController->processLogin();
        break;
        
    case 'logout':
        $authController->logout();
        break;
        
    default:
        header('Location: ' . BASE_URL . 'index.php');
        exit;
}
?>
