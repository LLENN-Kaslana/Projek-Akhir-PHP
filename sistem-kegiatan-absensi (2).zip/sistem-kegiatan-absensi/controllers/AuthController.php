<?php
/**
 * Controller Auth
 * Mengelola proses login dan logout
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/UserModel.php';

class AuthController {
    private $userModel;
    
    public function __construct() {
        $this->userModel = new UserModel();
    }
    
    /**
     * Menampilkan halaman login
     */
    public function showLoginPage() {
        // Jika sudah login, redirect ke dashboard
        if (isset($_SESSION['user_id'])) {
            $this->redirectToDashboard();
            exit;
        }
        
        require_once __DIR__ . '/../views/auth/login.php';
    }
    
    /**
     * Proses login
     */
    public function processLogin() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . BASE_URL . 'index.php');
            exit;
        }
        
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        
        // Validasi input
        if (empty($username) || empty($password)) {
            $_SESSION['error'] = 'Username dan password harus diisi!';
            header('Location: ' . BASE_URL . 'index.php');
            exit;
        }
        
        // Proses login
        $user = $this->userModel->login($username, $password);
        
        if ($user) {
            // Set session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['nama_lengkap'] = $user['nama_lengkap'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['foto_profil'] = $user['foto_profil'];
            
            $_SESSION['success'] = 'Login berhasil! Selamat datang, ' . $user['nama_lengkap'];
            
            // Redirect ke dashboard sesuai role
            $this->redirectToDashboard();
        } else {
            $_SESSION['error'] = 'Username atau password salah!';
            header('Location: ' . BASE_URL . 'index.php');
        }
        
        exit;
    }
    
    /**
     * Proses logout
     */
    public function logout() {
        // Hapus semua session
        session_unset();
        session_destroy();
        
        // Buat session baru untuk pesan
        session_start();
        $_SESSION['success'] = 'Logout berhasil!';
        
        header('Location: ' . BASE_URL . 'index.php');
        exit;
    }
    
    /**
     * Redirect ke dashboard sesuai role
     */
    private function redirectToDashboard() {
        $role = $_SESSION['role'] ?? '';
        
        if ($role === 'Admin') {
            header('Location: ' . BASE_URL . 'views/admin/dashboard.php');
        } else {
            header('Location: ' . BASE_URL . 'views/user/dashboard.php');
        }
    }
    
    /**
     * Cek apakah user sudah login
     */
    public static function checkLogin() {
        if (!isset($_SESSION['user_id'])) {
            $_SESSION['error'] = 'Anda harus login terlebih dahulu!';
            header('Location: ' . BASE_URL . 'index.php');
            exit;
        }
    }
    
    /**
     * Cek apakah user adalah admin
     */
    public static function checkAdmin() {
        self::checkLogin();
        
        if ($_SESSION['role'] !== 'Admin') {
            $_SESSION['error'] = 'Akses ditolak! Anda bukan Admin.';
            header('Location: ' . BASE_URL . 'views/user/dashboard.php');
            exit;
        }
    }
    
    /**
     * Cek apakah user adalah user biasa (bukan admin)
     */
    public static function checkUser() {
        self::checkLogin();
        
        if ($_SESSION['role'] === 'Admin') {
            header('Location: ' . BASE_URL . 'views/admin/dashboard.php');
            exit;
        }
    }
}
?>
