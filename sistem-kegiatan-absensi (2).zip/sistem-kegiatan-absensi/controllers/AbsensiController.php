<?php
/**
 * Controller Absensi
 * Mengelola CRUD data absensi
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/AbsensiModel.php';
require_once __DIR__ . '/../models/KegiatanModel.php';
require_once __DIR__ . '/AuthController.php';

class AbsensiController {
    private $absensiModel;
    private $kegiatanModel;
    
    public function __construct() {
        AuthController::checkLogin();
        $this->absensiModel = new AbsensiModel();
        $this->kegiatanModel = new KegiatanModel();
    }
    
    /**
     * Menampilkan daftar absensi
     */
    public function index() {
        $role = $_SESSION['role'] ?? '';
        
        if ($role === 'Admin') {
            // Admin bisa lihat semua absensi
            $absensiList = $this->absensiModel->getAllAbsensi();
            require_once __DIR__ . '/../views/admin/absensi/index.php';
        } else {
            // User hanya bisa lihat absensi milik sendiri
            $absensiList = $this->absensiModel->getAbsensiByUserId($_SESSION['user_id']);
            require_once __DIR__ . '/../views/user/absensi/index.php';
        }
    }
    
    /**
     * Menampilkan form tambah absensi (User)
     */
    public function create() {
        // Hanya user yang bisa create
        if ($_SESSION['role'] === 'Admin') {
            $_SESSION['error'] = 'Admin tidak dapat membuat absensi!';
            header('Location: ' . BASE_URL . 'views/admin/absensi/index.php');
            exit;
        }
        
        $kegiatanList = $this->kegiatanModel->getAllKegiatan();
        require_once __DIR__ . '/../views/user/absensi/create.php';
    }
    
    /**
     * Proses tambah absensi
     */
    public function store() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . BASE_URL . 'views/user/absensi/index.php');
            exit;
        }
        
        $data = [
            'kegiatan_id' => $_POST['kegiatan_id'] ?? '',
            'user_id' => $_SESSION['user_id'], // User yang login
            'tanggal_absen' => $_POST['tanggal_absen'] ?? '',
            'waktu_absen' => $_POST['waktu_absen'] ?? '',
            'status_kehadiran' => $_POST['status_kehadiran'] ?? '',
            'keterangan' => trim($_POST['keterangan'] ?? '')
        ];
        
        // Validasi
        if (empty($data['kegiatan_id']) || empty($data['tanggal_absen']) || 
            empty($data['waktu_absen']) || empty($data['status_kehadiran'])) {
            $_SESSION['error'] = 'Field wajib harus diisi!';
            header('Location: ' . BASE_URL . 'views/user/absensi/create.php');
            exit;
        }
        
        // Simpan data
        if ($this->absensiModel->createAbsensi($data)) {
            $_SESSION['success'] = 'Absensi berhasil ditambahkan!';
            header('Location: ' . BASE_URL . 'views/user/absensi/index.php');
        } else {
            $_SESSION['error'] = 'Gagal menambahkan absensi! Anda mungkin sudah absen untuk kegiatan ini pada tanggal tersebut.';
            header('Location: ' . BASE_URL . 'views/user/absensi/create.php');
        }
        
        exit;
    }
    
    /**
     * Menampilkan form edit absensi
     */
    public function edit($id) {
        $absensi = $this->absensiModel->getAbsensiById($id);
        
        if (!$absensi) {
            $_SESSION['error'] = 'Absensi tidak ditemukan!';
            $this->redirectBack();
            exit;
        }
        
        // User hanya bisa edit absensi milik sendiri
        if ($_SESSION['role'] !== 'Admin' && $absensi['user_id'] != $_SESSION['user_id']) {
            $_SESSION['error'] = 'Anda tidak memiliki akses untuk mengedit absensi ini!';
            $this->redirectBack();
            exit;
        }
        
        $kegiatanList = $this->kegiatanModel->getAllKegiatan();
        
        if ($_SESSION['role'] === 'Admin') {
            require_once __DIR__ . '/../views/admin/absensi/edit.php';
        } else {
            require_once __DIR__ . '/../views/user/absensi/edit.php';
        }
    }
    
    /**
     * Proses update absensi
     */
    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirectBack();
            exit;
        }
        
        // Cek kepemilikan absensi untuk user
        if ($_SESSION['role'] !== 'Admin') {
            $absensi = $this->absensiModel->getAbsensiById($id);
            if (!$absensi || $absensi['user_id'] != $_SESSION['user_id']) {
                $_SESSION['error'] = 'Anda tidak memiliki akses untuk mengedit absensi ini!';
                $this->redirectBack();
                exit;
            }
        }
        
        $data = [
            'tanggal_absen' => $_POST['tanggal_absen'] ?? '',
            'waktu_absen' => $_POST['waktu_absen'] ?? '',
            'status_kehadiran' => $_POST['status_kehadiran'] ?? '',
            'keterangan' => trim($_POST['keterangan'] ?? '')
        ];
        
        // Validasi
        if (empty($data['tanggal_absen']) || empty($data['waktu_absen']) || 
            empty($data['status_kehadiran'])) {
            $_SESSION['error'] = 'Field wajib harus diisi!';
            $this->redirectToEdit($id);
            exit;
        }
        
        // Update data
        if ($this->absensiModel->updateAbsensi($id, $data)) {
            $_SESSION['success'] = 'Absensi berhasil diupdate!';
            $this->redirectBack();
        } else {
            $_SESSION['error'] = 'Gagal mengupdate absensi!';
            $this->redirectToEdit($id);
        }
        
        exit;
    }
    
    /**
     * Helper: Redirect back sesuai role
     */
    private function redirectBack() {
        $role = $_SESSION['role'] ?? '';
        if ($role === 'Admin') {
            header('Location: ' . BASE_URL . 'views/admin/absensi/index.php');
        } else {
            header('Location: ' . BASE_URL . 'views/user/absensi/index.php');
        }
    }
    
    /**
     * Helper: Redirect to edit page
     */
    private function redirectToEdit($id) {
        $role = $_SESSION['role'] ?? '';
        if ($role === 'Admin') {
            header('Location: ' . BASE_URL . 'views/admin/absensi/edit.php?id=' . $id);
        } else {
            header('Location: ' . BASE_URL . 'views/user/absensi/edit.php?id=' . $id);
        }
    }
}
?>
