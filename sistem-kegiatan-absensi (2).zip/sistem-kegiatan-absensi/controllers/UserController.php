<?php
/**
 * Controller User
 * Mengelola CRUD data user (hanya untuk Admin)
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/UserModel.php';
require_once __DIR__ . '/AuthController.php';

class UserController {
    private $userModel;
    
    public function __construct() {
        AuthController::checkAdmin(); // Hanya admin yang bisa akses
        $this->userModel = new UserModel();
    }
    
    /**
     * Menampilkan daftar user
     */
    public function index() {
        $users = $this->userModel->getAllUsers();
        require_once __DIR__ . '/../views/admin/users/index.php';
    }
    
    /**
     * Menampilkan form tambah user
     */
    public function create() {
        require_once __DIR__ . '/../views/admin/users/create.php';
    }
    
    /**
     * Proses tambah user
     */
    public function store() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . BASE_URL . 'views/admin/users/index.php');
            exit;
        }
        
        $data = [
            'username' => trim($_POST['username'] ?? ''),
            'password' => $_POST['password'] ?? '',
            'nama_lengkap' => trim($_POST['nama_lengkap'] ?? ''),
            'email' => trim($_POST['email'] ?? ''),
            'role' => $_POST['role'] ?? ''
        ];
        
        // Validasi
        if (empty($data['username']) || empty($data['password']) || 
            empty($data['nama_lengkap']) || empty($data['email']) || empty($data['role'])) {
            $_SESSION['error'] = 'Semua field harus diisi!';
            header('Location: ' . BASE_URL . 'views/admin/users/create.php');
            exit;
        }
        
        if (strlen($data['password']) < 6) {
            $_SESSION['error'] = 'Password minimal 6 karakter!';
            header('Location: ' . BASE_URL . 'views/admin/users/create.php');
            exit;
        }
        
        // Simpan data
        if ($this->userModel->createUser($data)) {
            $_SESSION['success'] = 'User berhasil ditambahkan!';
            header('Location: ' . BASE_URL . 'views/admin/users/index.php');
        } else {
            $_SESSION['error'] = 'Gagal menambahkan user! Username mungkin sudah digunakan.';
            header('Location: ' . BASE_URL . 'views/admin/users/create.php');
        }
        
        exit;
    }
    
    /**
     * Menampilkan form edit user
     */
    public function edit($id) {
        $user = $this->userModel->getUserById($id);
        
        if (!$user) {
            $_SESSION['error'] = 'User tidak ditemukan!';
            header('Location: ' . BASE_URL . 'views/admin/users/index.php');
            exit;
        }
        
        require_once __DIR__ . '/../views/admin/users/edit.php';
    }
    
    /**
     * Proses update user
     */
    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . BASE_URL . 'views/admin/users/index.php');
            exit;
        }
        
        $data = [
            'username' => trim($_POST['username'] ?? ''),
            'nama_lengkap' => trim($_POST['nama_lengkap'] ?? ''),
            'email' => trim($_POST['email'] ?? ''),
            'role' => $_POST['role'] ?? ''
        ];
        
        // Validasi
        if (empty($data['username']) || empty($data['nama_lengkap']) || 
            empty($data['email']) || empty($data['role'])) {
            $_SESSION['error'] = 'Semua field harus diisi!';
            header('Location: ' . BASE_URL . 'views/admin/users/edit.php?id=' . $id);
            exit;
        }
        
        // Update data
        if ($this->userModel->updateUser($id, $data)) {
            $_SESSION['success'] = 'User berhasil diupdate!';
            header('Location: ' . BASE_URL . 'views/admin/users/index.php');
        } else {
            $_SESSION['error'] = 'Gagal mengupdate user! Username mungkin sudah digunakan.';
            header('Location: ' . BASE_URL . 'views/admin/users/edit.php?id=' . $id);
        }
        
        exit;
    }
    
    /**
     * Proses hapus user
     */
    public function delete($id) {
        // Jangan hapus diri sendiri
        if ($id == $_SESSION['user_id']) {
            $_SESSION['error'] = 'Anda tidak bisa menghapus akun sendiri!';
            header('Location: ' . BASE_URL . 'views/admin/users/index.php');
            exit;
        }
        
        if ($this->userModel->deleteUser($id)) {
            $_SESSION['success'] = 'User berhasil dihapus!';
        } else {
            $_SESSION['error'] = 'Gagal menghapus user!';
        }
        
        header('Location: ' . BASE_URL . 'views/admin/users/index.php');
        exit;
    }
}
?>
