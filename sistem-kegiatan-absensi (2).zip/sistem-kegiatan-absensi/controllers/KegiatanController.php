<?php
/**
 * Controller Kegiatan
 * Mengelola CRUD data kegiatan (hanya untuk Admin)
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/KegiatanModel.php';
require_once __DIR__ . '/../models/UserModel.php';
require_once __DIR__ . '/AuthController.php';

class KegiatanController {
    private $kegiatanModel;
    private $userModel;
    
    public function __construct() {
        AuthController::checkAdmin(); // Hanya admin yang bisa akses
        $this->kegiatanModel = new KegiatanModel();
        $this->userModel = new UserModel();
    }
    
    /**
     * Menampilkan daftar kegiatan
     */
    public function index() {
        $kegiatanList = $this->kegiatanModel->getAllKegiatan();
        require_once __DIR__ . '/../views/admin/kegiatan/index.php';
    }
    
    /**
     * Menampilkan form tambah kegiatan
     */
    public function create() {
        $users = $this->userModel->getAllUsers();
        require_once __DIR__ . '/../views/admin/kegiatan/create.php';
    }
    
    /**
     * Proses tambah kegiatan
     */
    public function store() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . BASE_URL . 'views/admin/kegiatan/index.php');
            exit;
        }
        
        $data = [
            'nama_kegiatan' => trim($_POST['nama_kegiatan'] ?? ''),
            'deskripsi' => trim($_POST['deskripsi'] ?? ''),
            'tanggal_mulai' => $_POST['tanggal_mulai'] ?? '',
            'tanggal_selesai' => $_POST['tanggal_selesai'] ?? '',
            'lokasi' => trim($_POST['lokasi'] ?? ''),
            'pic_id' => $_POST['pic_id'] ?? '',
            'status' => $_POST['status'] ?? 'Belum Mulai'
        ];
        
        // Validasi
        if (empty($data['nama_kegiatan']) || empty($data['tanggal_mulai']) || 
            empty($data['tanggal_selesai']) || empty($data['lokasi']) || empty($data['pic_id'])) {
            $_SESSION['error'] = 'Field wajib harus diisi!';
            header('Location: ' . BASE_URL . 'views/admin/kegiatan/create.php');
            exit;
        }
        
        // Validasi tanggal
        if (strtotime($data['tanggal_selesai']) < strtotime($data['tanggal_mulai'])) {
            $_SESSION['error'] = 'Tanggal selesai tidak boleh lebih awal dari tanggal mulai!';
            header('Location: ' . BASE_URL . 'views/admin/kegiatan/create.php');
            exit;
        }
        
        // Simpan data
        if ($this->kegiatanModel->createKegiatan($data)) {
            $_SESSION['success'] = 'Kegiatan berhasil ditambahkan!';
            header('Location: ' . BASE_URL . 'views/admin/kegiatan/index.php');
        } else {
            $_SESSION['error'] = 'Gagal menambahkan kegiatan!';
            header('Location: ' . BASE_URL . 'views/admin/kegiatan/create.php');
        }
        
        exit;
    }
    
    /**
     * Menampilkan form edit kegiatan
     */
    public function edit($id) {
        $kegiatan = $this->kegiatanModel->getKegiatanById($id);
        
        if (!$kegiatan) {
            $_SESSION['error'] = 'Kegiatan tidak ditemukan!';
            header('Location: ' . BASE_URL . 'views/admin/kegiatan/index.php');
            exit;
        }
        
        $users = $this->userModel->getAllUsers();
        require_once __DIR__ . '/../views/admin/kegiatan/edit.php';
    }
    
    /**
     * Proses update kegiatan
     */
    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: ' . BASE_URL . 'views/admin/kegiatan/index.php');
            exit;
        }
        
        $data = [
            'nama_kegiatan' => trim($_POST['nama_kegiatan'] ?? ''),
            'deskripsi' => trim($_POST['deskripsi'] ?? ''),
            'tanggal_mulai' => $_POST['tanggal_mulai'] ?? '',
            'tanggal_selesai' => $_POST['tanggal_selesai'] ?? '',
            'lokasi' => trim($_POST['lokasi'] ?? ''),
            'pic_id' => $_POST['pic_id'] ?? '',
            'status' => $_POST['status'] ?? ''
        ];
        
        // Validasi
        if (empty($data['nama_kegiatan']) || empty($data['tanggal_mulai']) || 
            empty($data['tanggal_selesai']) || empty($data['lokasi']) || empty($data['pic_id'])) {
            $_SESSION['error'] = 'Field wajib harus diisi!';
            header('Location: ' . BASE_URL . 'views/admin/kegiatan/edit.php?id=' . $id);
            exit;
        }
        
        // Validasi tanggal
        if (strtotime($data['tanggal_selesai']) < strtotime($data['tanggal_mulai'])) {
            $_SESSION['error'] = 'Tanggal selesai tidak boleh lebih awal dari tanggal mulai!';
            header('Location: ' . BASE_URL . 'views/admin/kegiatan/edit.php?id=' . $id);
            exit;
        }
        
        // Update data
        if ($this->kegiatanModel->updateKegiatan($id, $data)) {
            $_SESSION['success'] = 'Kegiatan berhasil diupdate!';
            header('Location: ' . BASE_URL . 'views/admin/kegiatan/index.php');
        } else {
            $_SESSION['error'] = 'Gagal mengupdate kegiatan!';
            header('Location: ' . BASE_URL . 'views/admin/kegiatan/edit.php?id=' . $id);
        }
        
        exit;
    }
    
    /**
     * Proses hapus kegiatan
     */
    public function delete($id) {
        if ($this->kegiatanModel->deleteKegiatan($id)) {
            $_SESSION['success'] = 'Kegiatan berhasil dihapus!';
        } else {
            $_SESSION['error'] = 'Gagal menghapus kegiatan!';
        }
        
        header('Location: ' . BASE_URL . 'views/admin/kegiatan/index.php');
        exit;
    }
}
?>
