<?php
/**
 * Controller Profile
 * Mengelola profil dan ubah password
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/UserModel.php';
require_once __DIR__ . '/AuthController.php';

class ProfileController {
    private $userModel;
    
    public function __construct() {
        AuthController::checkLogin();
        $this->userModel = new UserModel();
    }
    
    /**
     * Menampilkan halaman profil
     */
    public function index() {
        $user = $this->userModel->getUserById($_SESSION['user_id']);
        
        $role = $_SESSION['role'] ?? '';
        if ($role === 'Admin') {
            require_once __DIR__ . '/../views/admin/profile/index.php';
        } else {
            require_once __DIR__ . '/../views/user/profile/index.php';
        }
    }
    
    /**
     * Proses ubah password
     */
    public function changePassword() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->redirectToProfile();
            exit;
        }
        
        $passwordLama = $_POST['password_lama'] ?? '';
        $passwordBaru = $_POST['password_baru'] ?? '';
        $passwordKonfirmasi = $_POST['password_konfirmasi'] ?? '';
        
        // Validasi
        if (empty($passwordLama) || empty($passwordBaru) || empty($passwordKonfirmasi)) {
            $_SESSION['error'] = 'Semua field password harus diisi!';
            $this->redirectToProfile();
            exit;
        }
        
        if (strlen($passwordBaru) < 6) {
            $_SESSION['error'] = 'Password baru minimal 6 karakter!';
            $this->redirectToProfile();
            exit;
        }
        
        if ($passwordBaru !== $passwordKonfirmasi) {
            $_SESSION['error'] = 'Password baru dan konfirmasi password tidak cocok!';
            $this->redirectToProfile();
            exit;
        }
        
        // Verifikasi password lama
        if (!$this->userModel->verifyPassword($_SESSION['user_id'], $passwordLama)) {
            $_SESSION['error'] = 'Password lama tidak benar!';
            $this->redirectToProfile();
            exit;
        }
        
        // Update password
        if ($this->userModel->updatePassword($_SESSION['user_id'], $passwordBaru)) {
            $_SESSION['success'] = 'Password berhasil diubah!';
        } else {
            $_SESSION['error'] = 'Gagal mengubah password!';
        }
        
        $this->redirectToProfile();
        exit;
    }
    
    /**
     * Helper: Redirect to profile
     */
    private function redirectToProfile() {
        $role = $_SESSION['role'] ?? '';
        if ($role === 'Admin') {
            header('Location: ' . BASE_URL . 'views/admin/profile/index.php');
        } else {
            header('Location: ' . BASE_URL . 'views/user/profile/index.php');
        }
    }
}
?>
