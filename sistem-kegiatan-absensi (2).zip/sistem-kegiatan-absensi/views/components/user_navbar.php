<nav class="bg-gradient-to-r from-blue-600 to-purple-600 shadow-lg mb-8">
    <div class="container mx-auto px-4">
        <div class="flex items-center justify-between py-4">
            <div class="flex items-center space-x-3">
                <div class="bg-white w-10 h-10 rounded-lg flex items-center justify-center">
                    <i class="fas fa-calendar-check text-2xl text-blue-600"></i>
                </div>
                <span class="text-white font-bold text-xl hidden md:block">User Panel</span>
            </div>
            <div class="flex items-center space-x-2">
                <a href="<?php echo BASE_URL; ?>views/user/dashboard.php" class="px-4 py-2 rounded-lg font-medium transition duration-300 flex items-center <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'bg-white text-blue-600' : 'text-white hover:bg-white hover:bg-opacity-20'; ?>">
                    <i class="fas fa-tachometer-alt mr-2"></i><span class="hidden sm:inline">Dashboard</span>
                </a>
                <a href="<?php echo BASE_URL; ?>views/user/kegiatan/index.php" class="px-4 py-2 rounded-lg font-medium transition duration-300 flex items-center <?php echo strpos($_SERVER['PHP_SELF'], 'kegiatan') !== false ? 'bg-white text-blue-600' : 'text-white hover:bg-white hover:bg-opacity-20'; ?>">
                    <i class="fas fa-calendar-alt mr-2"></i><span class="hidden sm:inline">Kegiatan</span>
                </a>
                <a href="<?php echo BASE_URL; ?>views/user/absensi/index.php" class="px-4 py-2 rounded-lg font-medium transition duration-300 flex items-center <?php echo strpos($_SERVER['PHP_SELF'], 'absensi') !== false ? 'bg-white text-blue-600' : 'text-white hover:bg-white hover:bg-opacity-20'; ?>">
                    <i class="fas fa-clipboard-check mr-2"></i><span class="hidden sm:inline">Absensi</span>
                </a>
                <a href="<?php echo BASE_URL; ?>views/user/profile/index.php" class="px-4 py-2 rounded-lg font-medium transition duration-300 flex items-center <?php echo strpos($_SERVER['PHP_SELF'], 'profile') !== false ? 'bg-white text-blue-600' : 'text-white hover:bg-white hover:bg-opacity-20'; ?>">
                    <i class="fas fa-user-circle mr-2"></i><span class="hidden sm:inline">Profil</span>
                </a>
                <a href="<?php echo BASE_URL; ?>controllers/auth_handler.php?action=logout" onclick="return confirm('Yakin logout?')" class="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg font-medium transition duration-300 flex items-center">
                    <i class="fas fa-sign-out-alt mr-2"></i><span class="hidden sm:inline">Logout</span>
                </a>
            </div>
        </div>
    </div>
</nav>
