<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../controllers/AuthController.php';
require_once __DIR__ . '/../../models/KegiatanModel.php';
require_once __DIR__ . '/../../models/AbsensiModel.php';

AuthController::checkUser();

$kegiatanModel = new KegiatanModel();
$absensiModel = new AbsensiModel();

$kegiatanAktif = $kegiatanModel->getKegiatanAktif();
$absensiSaya = array_slice($absensiModel->getAbsensiByUserId($_SESSION['user_id']), 0, 5);
$totalAbsensiSaya = count($absensiModel->getAbsensiByUserId($_SESSION['user_id']));
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard User</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <?php include __DIR__ . '/../components/user_navbar.php'; ?>
    
    <div class="container mx-auto px-4 py-8">
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-800 mb-2"><i class="fas fa-tachometer-alt mr-3 text-blue-600"></i>Dashboard User</h1>
            <p class="text-gray-600">Selamat datang, <span class="font-semibold"><?php echo $_SESSION['nama_lengkap']; ?></span></p>
        </div>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded shadow">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-blue-500">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium mb-1">Total Absensi Saya</p>
                        <p class="text-3xl font-bold text-gray-800"><?php echo $totalAbsensiSaya; ?></p>
                    </div>
                    <div class="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center">
                        <i class="fas fa-clipboard-check text-3xl text-blue-600"></i>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-500 text-sm font-medium mb-1">Kegiatan Aktif</p>
                        <p class="text-3xl font-bold text-gray-800"><?php echo count($kegiatanAktif); ?></p>
                    </div>
                    <div class="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center">
                        <i class="fas fa-calendar-alt text-3xl text-green-600"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div class="bg-white rounded-xl shadow-lg p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4"><i class="fas fa-tasks mr-2 text-blue-600"></i>Kegiatan Aktif</h2>
                <?php if (empty($kegiatanAktif)): ?>
                    <p class="text-gray-500 text-center py-8">Tidak ada kegiatan aktif</p>
                <?php else: ?>
                    <div class="space-y-3">
                        <?php foreach ($kegiatanAktif as $kegiatan): ?>
                            <div class="border-l-4 border-blue-500 bg-blue-50 p-4 rounded">
                                <h3 class="font-semibold text-gray-800"><?php echo htmlspecialchars($kegiatan['nama_kegiatan']); ?></h3>
                                <p class="text-sm text-gray-600 mt-1"><i class="fas fa-calendar mr-1"></i><?php echo date('d M Y', strtotime($kegiatan['tanggal_mulai'])); ?> - <?php echo date('d M Y', strtotime($kegiatan['tanggal_selesai'])); ?></p>
                                <p class="text-sm text-gray-600 mt-1"><i class="fas fa-map-marker-alt mr-1"></i><?php echo htmlspecialchars($kegiatan['lokasi']); ?></p>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="bg-white rounded-xl shadow-lg p-6">
                <h2 class="text-xl font-bold text-gray-800 mb-4"><i class="fas fa-clock mr-2 text-purple-600"></i>Absensi Terbaru Saya</h2>
                <?php if (empty($absensiSaya)): ?>
                    <p class="text-gray-500 text-center py-8">Belum ada absensi</p>
                <?php else: ?>
                    <div class="space-y-3">
                        <?php foreach ($absensiSaya as $absensi): ?>
                            <div class="border-b border-gray-200 pb-3">
                                <p class="font-semibold text-gray-800"><?php echo htmlspecialchars($absensi['nama_kegiatan']); ?></p>
                                <p class="text-sm text-gray-600"><?php echo date('d M Y, H:i', strtotime($absensi['tanggal_absen'] . ' ' . $absensi['waktu_absen'])); ?></p>
                                <span class="px-2 py-1 text-xs font-semibold rounded-full <?php echo $absensi['status_kehadiran'] === 'Hadir' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'; ?>"><?php echo $absensi['status_kehadiran']; ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
