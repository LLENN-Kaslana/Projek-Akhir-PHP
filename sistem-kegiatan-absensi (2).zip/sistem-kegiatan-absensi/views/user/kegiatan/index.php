<?php
require_once __DIR__ . '/../../../config/config.php';
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../controllers/AuthController.php';
require_once __DIR__ . '/../../../models/KegiatanModel.php';

AuthController::checkUser();
$kegiatanModel = new KegiatanModel();
$kegiatanList = $kegiatanModel->getAllKegiatan();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lihat Kegiatan</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <?php include __DIR__ . '/../../components/user_navbar.php'; ?>
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold text-gray-800 mb-6"><i class="fas fa-calendar-alt mr-3 text-blue-600"></i>Daftar Kegiatan</h1>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach ($kegiatanList as $kegiatan): ?>
                <div class="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition">
                    <h3 class="text-xl font-bold text-gray-800 mb-3"><?php echo htmlspecialchars($kegiatan['nama_kegiatan']); ?></h3>
                    <p class="text-sm text-gray-600 mb-2"><i class="fas fa-align-left mr-2"></i><?php echo htmlspecialchars($kegiatan['deskripsi']); ?></p>
                    <p class="text-sm text-gray-600 mb-2"><i class="fas fa-calendar mr-2"></i><?php echo date('d M Y', strtotime($kegiatan['tanggal_mulai'])); ?> - <?php echo date('d M Y', strtotime($kegiatan['tanggal_selesai'])); ?></p>
                    <p class="text-sm text-gray-600 mb-3"><i class="fas fa-map-marker-alt mr-2"></i><?php echo htmlspecialchars($kegiatan['lokasi']); ?></p>
                    <span class="px-3 py-1 text-xs font-semibold rounded-full <?php echo $kegiatan['status'] === 'Selesai' ? 'bg-gray-100 text-gray-700' : ($kegiatan['status'] === 'Sedang Berjalan' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'); ?>"><?php echo $kegiatan['status']; ?></span>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>
