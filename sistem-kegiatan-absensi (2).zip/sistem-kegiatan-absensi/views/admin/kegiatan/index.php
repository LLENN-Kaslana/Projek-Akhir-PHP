<?php
require_once __DIR__ . '/../../../config/config.php';
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../controllers/AuthController.php';
require_once __DIR__ . '/../../../models/KegiatanModel.php';

AuthController::checkAdmin();
$kegiatanModel = new KegiatanModel();
$kegiatanList = $kegiatanModel->getAllKegiatan();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Kegiatan</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <?php include __DIR__ . '/../../components/admin_navbar.php'; ?>
    
    <div class="container mx-auto px-4 py-8">
        <div class="mb-6 flex justify-between items-center">
            <h1 class="text-3xl font-bold text-gray-800"><i class="fas fa-calendar-alt mr-3 text-blue-600"></i>Kelola Kegiatan</h1>
            <a href="create.php" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition shadow-lg">
                <i class="fas fa-plus mr-2"></i>Tambah Kegiatan
            </a>
        </div>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded shadow">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <div class="bg-white rounded-xl shadow-lg overflow-hidden">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">No</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nama Kegiatan</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tanggal</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Lokasi</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">PIC</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php if (empty($kegiatanList)): ?>
                            <tr><td colspan="7" class="px-6 py-8 text-center text-gray-500">Tidak ada data kegiatan</td></tr>
                        <?php else: ?>
                            <?php foreach ($kegiatanList as $index => $kegiatan): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 text-sm"><?php echo $index + 1; ?></td>
                                    <td class="px-6 py-4 text-sm font-medium"><?php echo htmlspecialchars($kegiatan['nama_kegiatan']); ?></td>
                                    <td class="px-6 py-4 text-sm"><?php echo date('d/m/Y', strtotime($kegiatan['tanggal_mulai'])); ?> - <?php echo date('d/m/Y', strtotime($kegiatan['tanggal_selesai'])); ?></td>
                                    <td class="px-6 py-4 text-sm"><?php echo htmlspecialchars($kegiatan['lokasi']); ?></td>
                                    <td class="px-6 py-4 text-sm"><?php echo htmlspecialchars($kegiatan['pic_nama']); ?></td>
                                    <td class="px-6 py-4"><span class="px-3 py-1 text-xs font-semibold rounded-full <?php echo $kegiatan['status'] === 'Selesai' ? 'bg-gray-100 text-gray-700' : ($kegiatan['status'] === 'Sedang Berjalan' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'); ?>"><?php echo $kegiatan['status']; ?></span></td>
                                    <td class="px-6 py-4 text-sm space-x-2">
                                        <a href="edit.php?id=<?php echo $kegiatan['id']; ?>" class="text-blue-600 hover:text-blue-900"><i class="fas fa-edit"></i></a>
                                        <a href="delete.php?id=<?php echo $kegiatan['id']; ?>" onclick="return confirm('Yakin?')" class="text-red-600 hover:text-red-900"><i class="fas fa-trash"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
