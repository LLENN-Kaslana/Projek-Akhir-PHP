<?php
require_once __DIR__ . '/../../../controllers/KegiatanController.php';
$controller = new KegiatanController();
$controller->delete($_GET['id'] ?? 0);
?>
