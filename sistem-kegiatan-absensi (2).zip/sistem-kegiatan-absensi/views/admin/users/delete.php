<?php
require_once __DIR__ . '/../../../controllers/UserController.php';
$controller = new UserController();
$id = $_GET['id'] ?? 0;
$controller->delete($id);
