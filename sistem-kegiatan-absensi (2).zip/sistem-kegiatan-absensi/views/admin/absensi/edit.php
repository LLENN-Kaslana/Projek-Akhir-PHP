<?php
require_once __DIR__ . '/../../../controllers/AbsensiController.php';
$controller = new AbsensiController();
$id = $_GET['id'] ?? 0;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller->update($id);
    exit;
}
$controller->edit($id);
?>
