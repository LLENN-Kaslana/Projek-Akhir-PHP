<?php
require_once __DIR__ . '/../../../config/config.php';
require_once __DIR__ . '/../../../config/database.php';
require_once __DIR__ . '/../../../controllers/AuthController.php';
require_once __DIR__ . '/../../../models/AbsensiModel.php';

AuthController::checkAdmin();

$absensiModel = new AbsensiModel();
$absensiList = $absensiModel->getAllAbsensi();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Absensi</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <?php include __DIR__ . '/../../components/admin_navbar.php'; ?>
    
    <div class="container mx-auto px-4 py-8">
        <div class="mb-6">
            <h1 class="text-3xl font-bold text-gray-800">
                <i class="fas fa-clipboard-check mr-3 text-blue-600"></i>Data Absensi
            </h1>
            <p class="text-gray-600 mt-2">Daftar semua absensi dari seluruh user</p>
        </div>

        <?php if (isset($_SESSION['success'])): ?>
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded shadow">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <div class="bg-white rounded-xl shadow-lg overflow-hidden">
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">No</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nama User</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Kegiatan</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tanggal</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Waktu</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Keterangan</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php if (empty($absensiList)): ?>
                            <tr><td colspan="7" class="px-6 py-8 text-center text-gray-500">Tidak ada data absensi</td></tr>
                        <?php else: ?>
                            <?php foreach ($absensiList as $index => $absensi): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 text-sm"><?php echo $index + 1; ?></td>
                                    <td class="px-6 py-4 text-sm font-medium"><?php echo htmlspecialchars($absensi['nama_user']); ?></td>
                                    <td class="px-6 py-4 text-sm"><?php echo htmlspecialchars($absensi['nama_kegiatan']); ?></td>
                                    <td class="px-6 py-4 text-sm"><?php echo date('d/m/Y', strtotime($absensi['tanggal_absen'])); ?></td>
                                    <td class="px-6 py-4 text-sm"><?php echo date('H:i', strtotime($absensi['waktu_absen'])); ?></td>
                                    <td class="px-6 py-4">
                                        <span class="px-3 py-1 text-xs font-semibold rounded-full
                                            <?php 
                                            echo $absensi['status_kehadiran'] === 'Hadir' ? 'bg-green-100 text-green-700' : 
                                                ($absensi['status_kehadiran'] === 'Izin' ? 'bg-blue-100 text-blue-700' : 
                                                ($absensi['status_kehadiran'] === 'Sakit' ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'));
                                            ?>">
                                            <?php echo $absensi['status_kehadiran']; ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-600"><?php echo htmlspecialchars($absensi['keterangan']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
