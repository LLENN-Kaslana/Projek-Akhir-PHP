# SISTEM INFORMASI MANAJEMEN KEGIATAN DAN ABSENSI

## DESKRIPSI
Aplikasi web untuk mengelola data kegiatan, absensi, dan laporan kehadiran secara terstruktur.

## TEKNOLOGI
- PHP 7.4+ (tanpa framework)
- MySQL Database
- Tailwind CSS
- JavaScript
- Arsitektur MVC

## FITUR UTAMA
### Admin:
- Login & Logout
- Dashboard dengan statistik
- CRUD Data User
- CRUD Data Kegiatan
- Melihat semua data absensi
- Melihat laporan kegiatan
- Ubah password

### User:
- Login & Logout
- Dashboard personal
- Membuat absensi
- Melihat data kegiatan & absensi
- Edit absensi milik sendiri
- Ubah password

## INSTALASI

### 1. Persiapan
- XAMPP / WAMP / LAMP
- PHP 7.4+
- MySQL 5.7+
- Web Browser modern

### 2. Langkah Instalasi

**a. Copy Folder**
```bash
Copy folder 'sistem-kegiatan-absensi' ke:
- XAMPP: C:/xampp/htdocs/
- WAMP: C:/wamp64/www/
```

**b. Import Database**
```
1. Buka phpMyAdmin (http://localhost/phpmyadmin)
2. Buat database baru: db_kegiatan_absensi
3. Import file: database.sql
```

**c. Konfigurasi**
```php
Edit file: config/config.php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', ''); // sesuaikan password MySQL
define('DB_NAME', 'db_kegiatan_absensi');
define('BASE_URL', 'http://localhost/sistem-kegiatan-absensi/');
```

**d. Jalankan Aplikasi**
```
Browser: http://localhost/sistem-kegiatan-absensi/
```

## LOGIN AKUN

### Admin
- Username: admin
- Password: admin123

### User
- Username: user1, user2, user3, user4
- Password: user123

## STRUKTUR FOLDER
```
sistem-kegiatan-absensi/
├── config/
│   ├── config.php          # Konfigurasi aplikasi
│   └── database.php        # Koneksi database
├── controllers/
│   ├── AuthController.php  # Controller autentikasi
│   ├── UserController.php  # Controller user (Admin)
│   ├── KegiatanController.php
│   ├── AbsensiController.php
│   └── ProfileController.php
├── models/
│   ├── UserModel.php       # Model user
│   ├── KegiatanModel.php   # Model kegiatan
│   └── AbsensiModel.php    # Model absensi
├── views/
│   ├── auth/
│   │   └── login.php       # Halaman login
│   ├── admin/              # Views untuk Admin
│   │   ├── dashboard.php
│   │   ├── users/
│   │   ├── kegiatan/
│   │   ├── absensi/
│   │   └── profile/
│   ├── user/               # Views untuk User
│   │   ├── dashboard.php
│   │   ├── kegiatan/
│   │   ├── absensi/
│   │   └── profile/
│   └── components/
│       ├── admin_navbar.php
│       └── user_navbar.php
├── assets/
│   ├── css/
│   ├── js/
│   └── images/
├── database.sql            # File SQL database
├── index.php               # Entry point
├── .htaccess              # Apache config
└── README.md              # Dokumentasi
```

## DATABASE SCHEMA

### Tabel: users
- id (PK)
- username
- password
- nama_lengkap
- email
- role (Admin, User 1-4)
- created_at

### Tabel: kegiatan
- id (PK)
- nama_kegiatan
- deskripsi
- tanggal_mulai
- tanggal_selesai
- lokasi
- pic_id (FK users)
- status

### Tabel: absensi
- id (PK)
- kegiatan_id (FK kegiatan)
- user_id (FK users)
- tanggal_absen
- waktu_absen
- status_kehadiran
- keterangan

## FITUR KEAMANAN
- Password hashing (bcrypt)
- Session management
- SQL Injection prevention
- XSS protection
- Role-based access control

## TROUBLESHOOTING

### Error: Database connection failed
- Pastikan MySQL sudah running
- Cek username/password di config.php
- Pastikan database sudah dibuat

### Error: Page not found
- Cek BASE_URL di config.php
- Pastikan mod_rewrite Apache aktif

### Error: Session not working
- Pastikan session.save_path dapat ditulis
- Cek php.ini untuk konfigurasi session

## PENGEMBANGAN LEBIH LANJUT
- Export laporan ke PDF/Excel
- Email notification
- Multi-language support
- REST API
- Mobile responsive enhancement

## SUPPORT
Untuk pertanyaan atau bug report, silakan hubungi pengembang.

## LISENSI
Project ini dibuat untuk keperluan pendidikan (Project Akhir).

---
© 2026 Sistem Manajemen Kegiatan & Absensi
