<?php
/**
 * Model User
 * Mengelola semua operasi database yang berhubungan dengan tabel users
 */

class UserModel {
    private $db;
    private $conn;
    
    public function __construct() {
        $this->db = new Database();
        $this->conn = $this->db->getConnection();
    }
    
    /**
     * Login - Validasi username dan password
     */
    public function login($username, $password) {
        $username = $this->db->escapeString($username);
        
        $query = "SELECT * FROM users WHERE username = '$username' LIMIT 1";
        $result = $this->conn->query($query);
        
        if ($result && $result->num_rows > 0) {
            $user = $result->fetch_assoc();
            
            // Verifikasi password
            if (password_verify($password, $user['password'])) {
                return $user;
            }
        }
        
        return false;
    }
    
    /**
     * Mendapatkan semua data user
     */
    public function getAllUsers() {
        $query = "SELECT id, username, nama_lengkap, email, role, foto_profil, created_at 
                  FROM users ORDER BY id ASC";
        $result = $this->conn->query($query);
        
        $users = [];
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $users[] = $row;
            }
        }
        
        return $users;
    }
    
    /**
     * Mendapatkan user berdasarkan ID
     */
    public function getUserById($id) {
        $id = (int)$id;
        
        $query = "SELECT * FROM users WHERE id = $id LIMIT 1";
        $result = $this->conn->query($query);
        
        if ($result && $result->num_rows > 0) {
            return $result->fetch_assoc();
        }
        
        return false;
    }
    
    /**
     * Menambah user baru
     */
    public function createUser($data) {
        $username = $this->db->escapeString($data['username']);
        $password = password_hash($data['password'], PASSWORD_DEFAULT);
        $nama_lengkap = $this->db->escapeString($data['nama_lengkap']);
        $email = $this->db->escapeString($data['email']);
        $role = $this->db->escapeString($data['role']);
        
        // Cek apakah username sudah ada
        $checkQuery = "SELECT id FROM users WHERE username = '$username'";
        $checkResult = $this->conn->query($checkQuery);
        
        if ($checkResult && $checkResult->num_rows > 0) {
            return false; // Username sudah ada
        }
        
        $query = "INSERT INTO users (username, password, nama_lengkap, email, role) 
                  VALUES ('$username', '$password', '$nama_lengkap', '$email', '$role')";
        
        return $this->conn->query($query);
    }
    
    /**
     * Update data user
     */
    public function updateUser($id, $data) {
        $id = (int)$id;
        $username = $this->db->escapeString($data['username']);
        $nama_lengkap = $this->db->escapeString($data['nama_lengkap']);
        $email = $this->db->escapeString($data['email']);
        $role = $this->db->escapeString($data['role']);
        
        // Cek apakah username sudah dipakai user lain
        $checkQuery = "SELECT id FROM users WHERE username = '$username' AND id != $id";
        $checkResult = $this->conn->query($checkQuery);
        
        if ($checkResult && $checkResult->num_rows > 0) {
            return false; // Username sudah dipakai
        }
        
        $query = "UPDATE users SET 
                  username = '$username',
                  nama_lengkap = '$nama_lengkap',
                  email = '$email',
                  role = '$role'
                  WHERE id = $id";
        
        return $this->conn->query($query);
    }
    
    /**
     * Hapus user
     */
    public function deleteUser($id) {
        $id = (int)$id;
        
        // Jangan hapus admin utama (id = 1)
        if ($id == 1) {
            return false;
        }
        
        $query = "DELETE FROM users WHERE id = $id";
        return $this->conn->query($query);
    }
    
    /**
     * Update password
     */
    public function updatePassword($id, $newPassword) {
        $id = (int)$id;
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        
        $query = "UPDATE users SET password = '$hashedPassword' WHERE id = $id";
        return $this->conn->query($query);
    }
    
    /**
     * Verifikasi password lama
     */
    public function verifyPassword($id, $password) {
        $user = $this->getUserById($id);
        
        if ($user) {
            return password_verify($password, $user['password']);
        }
        
        return false;
    }
    
    /**
     * Hitung total user
     */
    public function countUsers() {
        $query = "SELECT COUNT(*) as total FROM users";
        $result = $this->conn->query($query);
        
        if ($result) {
            $row = $result->fetch_assoc();
            return $row['total'];
        }
        
        return 0;
    }
}
?>
