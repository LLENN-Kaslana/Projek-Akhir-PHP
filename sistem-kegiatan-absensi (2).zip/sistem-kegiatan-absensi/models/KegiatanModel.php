<?php
/**
 * Model Kegiatan
 * Mengelola semua operasi database yang berhubungan dengan tabel kegiatan
 */

class KegiatanModel {
    private $db;
    private $conn;
    
    public function __construct() {
        $this->db = new Database();
        $this->conn = $this->db->getConnection();
    }
    
    /**
     * Mendapatkan semua data kegiatan dengan info PIC
     */
    public function getAllKegiatan() {
        $query = "SELECT k.*, u.nama_lengkap as pic_nama 
                  FROM kegiatan k
                  LEFT JOIN users u ON k.pic_id = u.id
                  ORDER BY k.tanggal_mulai DESC";
        $result = $this->conn->query($query);
        
        $kegiatan = [];
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $kegiatan[] = $row;
            }
        }
        
        return $kegiatan;
    }
    
    /**
     * Mendapatkan kegiatan berdasarkan ID
     */
    public function getKegiatanById($id) {
        $id = (int)$id;
        
        $query = "SELECT k.*, u.nama_lengkap as pic_nama 
                  FROM kegiatan k
                  LEFT JOIN users u ON k.pic_id = u.id
                  WHERE k.id = $id LIMIT 1";
        $result = $this->conn->query($query);
        
        if ($result && $result->num_rows > 0) {
            return $result->fetch_assoc();
        }
        
        return false;
    }
    
    /**
     * Menambah kegiatan baru
     */
    public function createKegiatan($data) {
        $nama_kegiatan = $this->db->escapeString($data['nama_kegiatan']);
        $deskripsi = $this->db->escapeString($data['deskripsi']);
        $tanggal_mulai = $this->db->escapeString($data['tanggal_mulai']);
        $tanggal_selesai = $this->db->escapeString($data['tanggal_selesai']);
        $lokasi = $this->db->escapeString($data['lokasi']);
        $pic_id = (int)$data['pic_id'];
        $status = $this->db->escapeString($data['status']);
        
        $query = "INSERT INTO kegiatan 
                  (nama_kegiatan, deskripsi, tanggal_mulai, tanggal_selesai, lokasi, pic_id, status) 
                  VALUES 
                  ('$nama_kegiatan', '$deskripsi', '$tanggal_mulai', '$tanggal_selesai', '$lokasi', $pic_id, '$status')";
        
        return $this->conn->query($query);
    }
    
    /**
     * Update data kegiatan
     */
    public function updateKegiatan($id, $data) {
        $id = (int)$id;
        $nama_kegiatan = $this->db->escapeString($data['nama_kegiatan']);
        $deskripsi = $this->db->escapeString($data['deskripsi']);
        $tanggal_mulai = $this->db->escapeString($data['tanggal_mulai']);
        $tanggal_selesai = $this->db->escapeString($data['tanggal_selesai']);
        $lokasi = $this->db->escapeString($data['lokasi']);
        $pic_id = (int)$data['pic_id'];
        $status = $this->db->escapeString($data['status']);
        
        $query = "UPDATE kegiatan SET 
                  nama_kegiatan = '$nama_kegiatan',
                  deskripsi = '$deskripsi',
                  tanggal_mulai = '$tanggal_mulai',
                  tanggal_selesai = '$tanggal_selesai',
                  lokasi = '$lokasi',
                  pic_id = $pic_id,
                  status = '$status'
                  WHERE id = $id";
        
        return $this->conn->query($query);
    }
    
    /**
     * Hapus kegiatan
     */
    public function deleteKegiatan($id) {
        $id = (int)$id;
        
        $query = "DELETE FROM kegiatan WHERE id = $id";
        return $this->conn->query($query);
    }
    
    /**
     * Hitung total kegiatan
     */
    public function countKegiatan() {
        $query = "SELECT COUNT(*) as total FROM kegiatan";
        $result = $this->conn->query($query);
        
        if ($result) {
            $row = $result->fetch_assoc();
            return $row['total'];
        }
        
        return 0;
    }
    
    /**
     * Hitung kegiatan berdasarkan status
     */
    public function countByStatus($status) {
        $status = $this->db->escapeString($status);
        
        $query = "SELECT COUNT(*) as total FROM kegiatan WHERE status = '$status'";
        $result = $this->conn->query($query);
        
        if ($result) {
            $row = $result->fetch_assoc();
            return $row['total'];
        }
        
        return 0;
    }
    
    /**
     * Mendapatkan kegiatan yang sedang berjalan
     */
    public function getKegiatanAktif() {
        $today = date('Y-m-d');
        
        $query = "SELECT k.*, u.nama_lengkap as pic_nama 
                  FROM kegiatan k
                  LEFT JOIN users u ON k.pic_id = u.id
                  WHERE k.status = 'Sedang Berjalan' 
                  OR (k.tanggal_mulai <= '$today' AND k.tanggal_selesai >= '$today')
                  ORDER BY k.tanggal_mulai ASC";
        $result = $this->conn->query($query);
        
        $kegiatan = [];
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $kegiatan[] = $row;
            }
        }
        
        return $kegiatan;
    }
}
?>
