<?php
/**
 * Model Absensi
 * Mengelola semua operasi database yang berhubungan dengan tabel absensi
 */

class AbsensiModel {
    private $db;
    private $conn;
    
    public function __construct() {
        $this->db = new Database();
        $this->conn = $this->db->getConnection();
    }
    
    /**
     * Mendapatkan semua data absensi
     */
    public function getAllAbsensi() {
        $query = "SELECT a.*, 
                  k.nama_kegiatan, 
                  u.nama_lengkap as nama_user
                  FROM absensi a
                  LEFT JOIN kegiatan k ON a.kegiatan_id = k.id
                  LEFT JOIN users u ON a.user_id = u.id
                  ORDER BY a.tanggal_absen DESC, a.waktu_absen DESC";
        $result = $this->conn->query($query);
        
        $absensi = [];
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $absensi[] = $row;
            }
        }
        
        return $absensi;
    }
    
    /**
     * Mendapatkan absensi berdasarkan user ID
     */
    public function getAbsensiByUserId($userId) {
        $userId = (int)$userId;
        
        $query = "SELECT a.*, 
                  k.nama_kegiatan, 
                  u.nama_lengkap as nama_user
                  FROM absensi a
                  LEFT JOIN kegiatan k ON a.kegiatan_id = k.id
                  LEFT JOIN users u ON a.user_id = u.id
                  WHERE a.user_id = $userId
                  ORDER BY a.tanggal_absen DESC, a.waktu_absen DESC";
        $result = $this->conn->query($query);
        
        $absensi = [];
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $absensi[] = $row;
            }
        }
        
        return $absensi;
    }
    
    /**
     * Mendapatkan absensi berdasarkan ID
     */
    public function getAbsensiById($id) {
        $id = (int)$id;
        
        $query = "SELECT a.*, 
                  k.nama_kegiatan, 
                  u.nama_lengkap as nama_user
                  FROM absensi a
                  LEFT JOIN kegiatan k ON a.kegiatan_id = k.id
                  LEFT JOIN users u ON a.user_id = u.id
                  WHERE a.id = $id LIMIT 1";
        $result = $this->conn->query($query);
        
        if ($result && $result->num_rows > 0) {
            return $result->fetch_assoc();
        }
        
        return false;
    }
    
    /**
     * Menambah absensi baru
     */
    public function createAbsensi($data) {
        $kegiatan_id = (int)$data['kegiatan_id'];
        $user_id = (int)$data['user_id'];
        $tanggal_absen = $this->db->escapeString($data['tanggal_absen']);
        $waktu_absen = $this->db->escapeString($data['waktu_absen']);
        $status_kehadiran = $this->db->escapeString($data['status_kehadiran']);
        $keterangan = $this->db->escapeString($data['keterangan']);
        
        // Cek apakah sudah absen hari ini untuk kegiatan yang sama
        $checkQuery = "SELECT id FROM absensi 
                       WHERE kegiatan_id = $kegiatan_id 
                       AND user_id = $user_id 
                       AND tanggal_absen = '$tanggal_absen'";
        $checkResult = $this->conn->query($checkQuery);
        
        if ($checkResult && $checkResult->num_rows > 0) {
            return false; // Sudah absen hari ini
        }
        
        $query = "INSERT INTO absensi 
                  (kegiatan_id, user_id, tanggal_absen, waktu_absen, status_kehadiran, keterangan) 
                  VALUES 
                  ($kegiatan_id, $user_id, '$tanggal_absen', '$waktu_absen', '$status_kehadiran', '$keterangan')";
        
        return $this->conn->query($query);
    }
    
    /**
     * Update data absensi
     */
    public function updateAbsensi($id, $data) {
        $id = (int)$id;
        $tanggal_absen = $this->db->escapeString($data['tanggal_absen']);
        $waktu_absen = $this->db->escapeString($data['waktu_absen']);
        $status_kehadiran = $this->db->escapeString($data['status_kehadiran']);
        $keterangan = $this->db->escapeString($data['keterangan']);
        
        $query = "UPDATE absensi SET 
                  tanggal_absen = '$tanggal_absen',
                  waktu_absen = '$waktu_absen',
                  status_kehadiran = '$status_kehadiran',
                  keterangan = '$keterangan'
                  WHERE id = $id";
        
        return $this->conn->query($query);
    }
    
    /**
     * Hapus absensi
     */
    public function deleteAbsensi($id) {
        $id = (int)$id;
        
        $query = "DELETE FROM absensi WHERE id = $id";
        return $this->conn->query($query);
    }
    
    /**
     * Hitung total absensi
     */
    public function countAbsensi() {
        $query = "SELECT COUNT(*) as total FROM absensi";
        $result = $this->conn->query($query);
        
        if ($result) {
            $row = $result->fetch_assoc();
            return $row['total'];
        }
        
        return 0;
    }
    
    /**
     * Hitung absensi berdasarkan status kehadiran
     */
    public function countByStatus($status) {
        $status = $this->db->escapeString($status);
        
        $query = "SELECT COUNT(*) as total FROM absensi WHERE status_kehadiran = '$status'";
        $result = $this->conn->query($query);
        
        if ($result) {
            $row = $result->fetch_assoc();
            return $row['total'];
        }
        
        return 0;
    }
    
    /**
     * Mendapatkan absensi berdasarkan kegiatan
     */
    public function getAbsensiByKegiatan($kegiatanId) {
        $kegiatanId = (int)$kegiatanId;
        
        $query = "SELECT a.*, 
                  u.nama_lengkap as nama_user
                  FROM absensi a
                  LEFT JOIN users u ON a.user_id = u.id
                  WHERE a.kegiatan_id = $kegiatanId
                  ORDER BY a.tanggal_absen DESC, a.waktu_absen DESC";
        $result = $this->conn->query($query);
        
        $absensi = [];
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $absensi[] = $row;
            }
        }
        
        return $absensi;
    }
    
    /**
     * Cek apakah user sudah absen untuk kegiatan tertentu pada tanggal tertentu
     */
    public function sudahAbsen($kegiatanId, $userId, $tanggal) {
        $kegiatanId = (int)$kegiatanId;
        $userId = (int)$userId;
        $tanggal = $this->db->escapeString($tanggal);
        
        $query = "SELECT id FROM absensi 
                  WHERE kegiatan_id = $kegiatanId 
                  AND user_id = $userId 
                  AND tanggal_absen = '$tanggal'
                  LIMIT 1";
        $result = $this->conn->query($query);
        
        return $result && $result->num_rows > 0;
    }
}
?>
