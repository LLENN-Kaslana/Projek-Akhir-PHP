<?php
/**
 * Script untuk memperbaiki password hash di database
 * Jalankan sekali setelah import database.sql
 */

require_once 'config/config.php';
require_once 'config/database.php';

echo "=== MEMPERBAIKI PASSWORD HASH ===\n\n";

try {
    $db = new Database();
    $conn = $db->getConnection();

    // Generate hash yang benar
    $adminHash = password_hash('admin123', PASSWORD_DEFAULT);
    $userHash = password_hash('user123', PASSWORD_DEFAULT);

    echo "Hash baru untuk admin: $adminHash\n";
    echo "Hash baru untuk user: $userHash\n\n";

    // Update password admin
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE username = 'admin'");
    $stmt->bind_param("s", $adminHash);
    if ($stmt->execute()) {
        echo "✅ Password admin berhasil diperbarui\n";
    } else {
        echo "❌ Gagal update password admin\n";
    }

    // Update password semua user
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE username LIKE 'user%'");
    $stmt->bind_param("s", $userHash);
    if ($stmt->execute()) {
        echo "✅ Password user berhasil diperbarui\n";
    } else {
        echo "❌ Gagal update password user\n";
    }

    echo "\n=== TEST LOGIN SETELAH PERBAIKAN ===\n";

    // Test login admin
    $result = $conn->query("SELECT * FROM users WHERE username = 'admin'");
    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify('admin123', $user['password'])) {
            echo "✅ Login admin berhasil\n";
        } else {
            echo "❌ Login admin masih gagal\n";
        }
    }

    // Test login user1
    $result = $conn->query("SELECT * FROM users WHERE username = 'user1'");
    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify('user123', $user['password'])) {
            echo "✅ Login user1 berhasil\n";
        } else {
            echo "❌ Login user1 masih gagal\n";
        }
    }

    echo "\n=== SELESAI ===\n";
    echo "Sekarang Anda bisa login dengan:\n";
    echo "- Admin: admin / admin123\n";
    echo "- User: user1 / user123\n";

} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "\n";
}
?>
