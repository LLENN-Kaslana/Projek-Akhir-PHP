<?php
/**
 * Index.php - Halaman Login
 * Entry point aplikasi
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/controllers/AuthController.php';

$authController = new AuthController();
$authController->showLoginPage();
?>
