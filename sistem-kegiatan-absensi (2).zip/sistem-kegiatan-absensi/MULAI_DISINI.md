# 🚀 MULAI DI SINI - Quick Start Guide

## Selamat Datang di Sistem Manajemen Kegiatan & Absensi!

Project akhir Anda sudah **100% SIAP DIGUNAKAN**! 🎉

---

## 📋 Langkah Cepat (5 Menit)

### 1️⃣ Install XAMPP
- Download dari: https://www.apachefriends.org/
- Install di komputer Anda
- Jalankan XAMPP Control Panel
- Start **Apache** dan **MySQL**

### 2️⃣ Copy Folder Aplikasi
- Copy folder `sistem-kegiatan-absensi` ini
- Paste ke: `C:\xampp\htdocs\` (Windows) atau `/Applications/XAMPP/htdocs/` (Mac)

### 3️⃣ Import Database
- Buka browser, ketik: `http://localhost/phpmyadmin`
- Klik "New" untuk buat database baru
- Nama database: `db_kegiatan_absensi`
- Klik tab "Import"
- Pilih file `database.sql` dari folder ini
- Klik "Go"

### 4️⃣ Jalankan Aplikasi
- Buka browser
- Ketik: `http://localhost/sistem-kegiatan-absensi/`
- Login dengan:
  - **Admin**: username: `admin`, password: `admin123`
  - **User**: username: `user1`, password: `user123`

---

## ✅ File Apa Saja yang Ada?

### File Utama:
- ✅ `database.sql` - Database lengkap
- ✅ `index.php` - Halaman login
- ✅ `README.md` - Dokumentasi lengkap
- ✅ `PANDUAN_INSTALASI.md` - Panduan detail step-by-step

### Folder Aplikasi:
- ✅ `config/` - Konfigurasi database (2 files)
- ✅ `controllers/` - Logic aplikasi (6 files)
- ✅ `models/` - Query database (3 files)
- ✅ `views/` - Tampilan halaman (33+ files)
  - `views/admin/` - Halaman untuk Admin
  - `views/user/` - Halaman untuk User
  - `views/auth/` - Halaman login
  - `views/components/` - Navbar
- ✅ `assets/` - CSS, JS, Images (opsional)

### Total: 33 File PHP + 1 File SQL + Dokumentasi Lengkap

---

## 🎯 Fitur Aplikasi

### Admin dapat:
- ✅ Kelola User (Tambah, Edit, Hapus)
- ✅ Kelola Kegiatan (Tambah, Edit, Hapus)
- ✅ Lihat semua Absensi
- ✅ Dashboard dengan statistik
- ✅ Ubah password

### User dapat:
- ✅ Lihat daftar Kegiatan
- ✅ Buat Absensi baru
- ✅ Lihat & Edit Absensi sendiri
- ✅ Dashboard personal
- ✅ Ubah password

---

## 🛠️ Teknologi

- **PHP Murni** (tanpa framework)
- **Konsep MVC** (Model-View-Controller)
- **MySQL** Database
- **Tailwind CSS** (via CDN)
- **Font Awesome** Icons
- **CRUD Lengkap**
- **Role-Based Access Control**

---

## 📖 Butuh Bantuan?

### Baca Dokumentasi:
1. **README.md** - Overview aplikasi
2. **PANDUAN_INSTALASI.md** - Instalasi detail dengan troubleshooting
3. **TESTING_CHECKLIST.md** - Checklist untuk testing sebelum presentasi
4. **FILE_LIST.md** - Daftar lengkap semua file

### Jika Ada Error:
- Pastikan XAMPP sudah running
- Cek `config/config.php` untuk konfigurasi database
- Lihat bagian Troubleshooting di `PANDUAN_INSTALASI.md`

---

## 🎓 Tips Presentasi

### Persiapan:
1. Test aplikasi 1 hari sebelum presentasi
2. Pastikan semua fitur berfungsi (gunakan TESTING_CHECKLIST.md)
3. Siapkan penjelasan tentang:
   - Konsep MVC
   - Role-based access control
   - Fitur keamanan (password hashing, session)

### Saat Demo:
1. Login sebagai Admin → tunjukkan CRUD User & Kegiatan
2. Logout → Login sebagai User → tunjukkan Create & Edit Absensi
3. Highlight: User tidak bisa hapus, tidak bisa lihat data user lain

### Highlight Teknis:
- ✅ Arsitektur MVC yang terstruktur
- ✅ Separation of concerns (Model, View, Controller terpisah)
- ✅ Security: Password hashing dengan bcrypt
- ✅ Security: SQL Injection prevention
- ✅ Security: Session-based authentication
- ✅ Responsive design dengan Tailwind CSS
- ✅ Form validation
- ✅ Role-based authorization

---

## 🔐 Akun Login

### Akun Admin:
```
Username: admin
Password: admin123
```

### Akun User (4 akun tersedia):
```
Username: user1, user2, user3, user4
Password: user123 (untuk semua user)
```

⚠️ **Penting:** Ubah password setelah login pertama kali melalui menu Profil!

---

## 📊 Database Schema

### 3 Tabel Utama:

1. **users** - Menyimpan data pengguna
2. **kegiatan** - Menyimpan data kegiatan
3. **absensi** - Menyimpan data absensi

### Relasi:
- `kegiatan.pic_id` → `users.id` (PIC kegiatan)
- `absensi.kegiatan_id` → `kegiatan.id`
- `absensi.user_id` → `users.id`

---

## ⚙️ Konfigurasi (Jika Perlu)

File: `config/config.php`

```php
// Konfigurasi Database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');  // Kosongkan jika password MySQL kosong
define('DB_NAME', 'db_kegiatan_absensi');

// Base URL
define('BASE_URL', 'http://localhost/sistem-kegiatan-absensi/');
```

---

## ✨ Selamat Mengerjakan Project!

Aplikasi ini sudah lengkap dan siap digunakan untuk Project Akhir Anda.

Semua fitur sudah terimplementasi dengan baik:
- ✅ Login & Logout
- ✅ Role-based access (Admin & User)
- ✅ CRUD lengkap
- ✅ Dashboard
- ✅ Responsive design
- ✅ Security features

**Good luck dengan presentasi Anda! 🚀**

---

© 2026 Sistem Manajemen Kegiatan & Absensi
Dibuat untuk Project Akhir
